<?php

class ChartsController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        // action body
        // $this->view->InlineScript()->appendFile('/assets/vendor/chart.js/Chart.min.js');
    }


}

